#ifndef ESTADIO_H_INCLUDED
#define ESTADIO_H_INCLUDED


struct EstadioE;

typedef struct EstadioE * EstadioPtr;

EstadioPtr crearEstadio(int cap, char nom[20]);

void mostrarEstadio(EstadioPtr e);



#endif // ESTADIO_H_INCLUDED
