#include <stdio.h>
#include <stdlib.h>

#include "jugador.h"



struct JugadorE{

    int numero;
    char apellido[20];

};



JugadorPtr crearJugador(int num, char ape[20]);

void mostrarJugador(JugadorPtr j){


    printf("/t-----JUGADOR----\n");
    printf("APELLIDO: %s - NUM: %d", j->apellido, j->numero);

};
