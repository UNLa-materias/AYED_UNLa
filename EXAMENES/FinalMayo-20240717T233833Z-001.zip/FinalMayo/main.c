#include <stdio.h>
#include <stdlib.h>

#include "lista.h"

/// 1- Construir todo el programa bajo TDA
/// Muchas cosas las pueden reutilizar, lo que falte deberan desarrollarlo

/// 2- El estadio debe tener una lista de jugadores
/// 3- Crear un estadio y crear 5 jugadores. (Insertar los jugadores en la lista del estadio)
/// 4- Mostrar el estadio con los jugadores
/// 5- Ordenar la lista de jugadores por apellido y mostrar otra vez el estadio
/// --- Hasta ac� requisito de aprobacion -----
/// 6- Eliminar de la lista a un jugador buscado por apellido
/// 7- Duplicar la lista y mostrar el duplicado

int main()
{




    return 0;
}
