#include <stdio.h>
#include <stdlib.h>

#include "estadio.h"


struct EstadioE{

    int capacidad;
    char nombre[20];

};


EstadioPtr crearEstadio(int cap, char nom[20]);

void mostrarEstadio(EstadioPtr e){

    printf("---------ESTADIO---------\n");
    printf("NOMBRE: %s -- CAP: %d\n", e->nombre, e->capacidad);

};
