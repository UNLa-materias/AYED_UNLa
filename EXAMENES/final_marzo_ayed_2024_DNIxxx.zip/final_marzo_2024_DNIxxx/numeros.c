#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "numeros.h"


struct Numeros{

    char color[20];
    int sorteo[3][4];

};


NumerosPtr crearNumeros(char c[20], int s[3][4]){

    NumerosPtr n = malloc(sizeof(struct Numeros));

    strcpy(n->color, c);


    //Cargo los numeros que vinieron por parametro
    for (int i = 0 ; i<3; i++){

        for (int j=0; j<4; j++){

            n->sorteo[i][j] = s[i][j];

        }
    }

    return n;

};


NumerosPtr crearNumerosAleatorios(){
     NumerosPtr n = malloc(sizeof(struct Numeros));

     //Completar

     return n;
};

void mostrarNumeros(NumerosPtr n){

    printf("\n------NUMEROS--COLOR: %s-----\n",n->color);
    for (int i = 0 ; i<3; i++){

        for (int j=0; j<4; j++){

            printf(" %d ", n->sorteo[i][j]);

        }

        printf("\n");

    }

};

void eliminarNumeros(NumerosPtr n){

    free(n);


    };

///Getters y setters que correspondan
