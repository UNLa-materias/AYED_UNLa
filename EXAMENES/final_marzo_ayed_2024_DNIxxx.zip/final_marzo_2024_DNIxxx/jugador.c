
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "jugador.h"


struct Jugador{

    char nombre[20];
    int dni;

    //anidar con la lista de Numeros

};



JugadorPtr crearJugador(char n[20], int d){

    JugadorPtr j = (JugadorPtr)  malloc(sizeof(struct Jugador));

    strcpy(j->nombre, n);

    j->dni = d;

    //anidar los 3 cartones
    //iniciar o settear como corresponda.

    return j;

};

void mostrarJugador(JugadorPtr j){

    printf("\n------JUGADOR-----\n");
    printf("\tNOMBRE: %s\n", j->nombre);
    printf("\tDNI: %d\n", j->dni);

    //debe mostrar tambien los cartones comprados

};



void destruirJugador(JugadorPtr j){
    free(j);

    };

///Hacer
void agregarCarton(JugadorPtr j, NumerosPtr n){};

void verificarCartones(JugadorPtr j, NumerosPtr n){};


///Getters y setters que correspondan
